Estatísticas que predizem a saúde:
Este projeto visa criar um sistema de monitoramento que detecte os obstáculos que indivíduos de baixa renda encontram ao tentar acessar serviços de saúde.


# Características
- Coleta de informações demográficas e sanitárias.
- Exame do tempo de espera e contentamento com o serviço prestado.
- Sugestões para aprimorar o acesso à saúde.

# Tecnologias Empregadas

- Python
- Pandas
- PostgreSQL
- BigData
- Bootstrap
  
#Contribuição
Este trabalho totalmente aberto para melhorias ou correções!